const fs = require("node:fs");
const path = require("node:path");

function parseLines(file) {
  const text = fs.readFileSync(file, "utf8");
  return text.trim().length ? text.trim().split(/\n/).map(l => JSON.parse(l)) : [];
}

async function normalizeUnifiedToNightFeatures(rawDir, featDir, opts = {}) {
  const files = fs.readdirSync(rawDir).filter(f => f.endsWith(".json") || f.endsWith(".jsonl"));
  const perNight = {};
  for (const f of files) {
    const full = path.join(rawDir, f);
    const lines = f.endsWith(".jsonl") ? parseLines(full) : fs.readFileSync(full, "utf8").trim().split(/\n/).map(l => JSON.parse(l));
    for (const r of lines) {
      const d = new Date(r.start_utc);
      const nightKey = d.toISOString().slice(0,10); // TODO: replace with your noon cutoff logic
      perNight[nightKey] ||= { night_key: nightKey, adherence7d: 0, overrideCount7d: 0, bedtimeStdDevMin14d: 0, isWorkday: false, whoopRecoveryPct: null, hrvScore: null };
      if (r.record_type === "hrv" && typeof r.value === "number") perNight[nightKey].hrvScore = r.value;
    }
  }
  const out = path.join(featDir, `night_features_${Date.now()}.jsonl`);
  fs.mkdirSync(featDir, { recursive: true });
  fs.writeFileSync(out, Object.values(perNight).map(o => JSON.stringify(o)).join("\n"));
  return out;
}

module.exports = { normalizeUnifiedToNightFeatures };
